package ggc.core.notifications;

public interface Observer {
    void notify(Notification notification);
}
