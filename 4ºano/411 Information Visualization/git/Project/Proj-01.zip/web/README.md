The project was made for ms edge and was ment to be used on a 1920x1080 screen in full screen
