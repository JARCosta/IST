#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
# export PATH=/home/vagrant/cnv/aws-java-sdk-1.12.730:$PATH
export AWS_DEFAULT_REGION=us-east-1
export AWS_ACCOUNT_ID=471112608834
export AWS_ACCESS_KEY_ID=AKIAW3MD75RBCUN6ONRG
export AWS_SECRET_ACCESS_KEY=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
# export AWS_EC2_SSH_KEYPAR_PATH=jarkeypair
# export AWS_SECURITY_GROUP=default
# export AWS_KEYPAIR_NAME=jarkeypair


# export AWS_ACCESS_KEY_ID="AKIAW3MD75RBCUN6ONRG"
# export AWS_SECRET_ACCESS_KEY="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"
# export AWS_DEFAULT_REGION="us-east-1"

# export AWS_ACCESS_KEY_ID="AKIAW3MD75RBDH5ABZV7"
# export AWS_SECRET_ACCESS_KEY="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"
# export AWS_DEFAULT_REGION="us-east-1"
