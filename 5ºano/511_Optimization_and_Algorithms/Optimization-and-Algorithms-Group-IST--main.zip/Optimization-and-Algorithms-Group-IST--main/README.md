# Optimization-and-Algorithms-Group-IST-
Personal Group used to solve some tasks of the Optimization and Algorithms project.

The components of this group are:

-Lino Di Lucia
-Pascal Seitter
-João Costa
-Matteo Tale
